// Constants for the estimator
export type WallType =
  | "civil"
  | "gypsum"
  | "plywood"
  | "gypsum-plywood"
  | "gypsum-glass"
  | "plywood-glass";

export const wallOptions = [
  { label: "Civil Wall", value: "civil" },
  { label: "Gypsum", value: "gypsum" },
  { label: "Plywood", value: "plywood" },
  { label: "Gypsum + Plywood", value: "gypsum-plywood" },
  { label: "Gypsum + Glass", value: "gypsum-glass" },
  { label: "Plywood + Glass", value: "plywood-glass" },
];

export const subOptionsMap: Partial<Record<WallType, string[]>> = {
  civil: ["9 inch", "4.5 inch"],
  gypsum: ["Single Glazing", "Double Glazing"],
};

export const plywoodTypes = ["Commercial 8/4", "Marine 8/4", "BWP 8/4", "BWR 8/4"];
export const glazingOptions = ["Single Glazing", "Double Glazing"];
export const glassTypes = ["Clear Glass", "Toughened Glass", "Fully Frosted"];
export const finishOptions = ["Laminate Finish", "Paint Finish"];
export const beadingOptions = ["Rubber Beeding", "Wooden Beeding"];
export const frameOptions = ["Aluminium Frame", "Wooden Frame"];

// Helper for rates
export const getOptionRate = (option: string) => {
  const rates: Record<string, number> = {
    "Clear Glass": 1200,
    "Toughened Glass": 1800,
    "Fully Frosted": 1500,
    "Rubber Beeding": 50,
    "Wooden Beeding": 100,
    "Laminate Finish": 500,
    "Paint Finish": 300,
    "Aluminium Frame": 2000,
    "Wooden Frame": 1800,
    "9 inch": 1200,
    "4.5 inch": 800,
    "Civil Wall": 100, // base rate placeholder
    "Gypsum": 150,
    "Plywood": 200,
  };
  return rates[option] ?? 0;
};
