import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

// Types
export interface Shop {
  id: number;
  name: string;
  location: string;
  phone: string;
  image?: string;
  rating?: number;
  categories?: string[];
}

export interface Material {
  id: number;
  shopId: number;
  name: string;
  code: string;
  rate: number;
  unit: string;
  category: string;
  image?: string;
}

interface DataContextType {
  shops: Shop[];
  materials: Material[];
  addShop: (shop: Omit<Shop, "id">) => void;
  addMaterial: (material: Omit<Material, "id">) => void;
  getMaterialsByShop: (shopId: number) => Material[];
  cart: { materialId: number; quantity: number }[];
  addToCart: (materialId: number, quantity: number) => void;
  updateCartQuantity: (materialId: number, quantity: number) => void;
  removeFromCart: (materialId: number) => void;
  clearCart: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

// Initial Mock Data
const INITIAL_SHOPS: Shop[] = [
  {
    id: 1,
    name: "City Build Supplies",
    location: "Downtown",
    rating: 4.8,
    phone: "+1 234 567 890",
    categories: ["Civil", "Plumbing", "Electrical"],
    image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&q=80&w=256&h=256"
  },
  {
    id: 2,
    name: "Premium Interiors & Glass",
    location: "Westside Industrial",
    rating: 4.9,
    phone: "+1 987 654 321",
    categories: ["Glass", "Plywood", "Hardware"],
    image: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&q=80&w=256&h=256"
  },
];

const INITIAL_MATERIALS: Material[] = [
  { id: 1, shopId: 1, name: "UltraTech Cement", code: "CEM-001", rate: 380, unit: "bag", category: "Civil", image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=100&h=100" },
  { id: 2, shopId: 1, name: "River Sand", code: "SND-001", rate: 45, unit: "cft", category: "Civil", image: "https://images.unsplash.com/photo-1621262332675-5735f52eb5df?auto=format&fit=crop&q=80&w=100&h=100" },
  { id: 3, shopId: 1, name: "Red Bricks", code: "BRK-001", rate: 8, unit: "pcs", category: "Civil", image: "https://images.unsplash.com/photo-1590074251261-0f3056461c28?auto=format&fit=crop&q=80&w=100&h=100" },
  { id: 4, shopId: 2, name: "Greenply 18mm", code: "PLY-001", rate: 95, unit: "sq.ft", category: "Plywood", image: "https://images.unsplash.com/photo-1546554137-f86b9593a222?auto=format&fit=crop&q=80&w=100&h=100" },
  { id: 5, shopId: 2, name: "Saint Gobain 12mm Toughened", code: "GLS-001", rate: 180, unit: "sq.ft", category: "Glass", image: "https://images.unsplash.com/photo-1506155708848-d0b87704df37?auto=format&fit=crop&q=80&w=100&h=100" },
];

export const DataProvider = ({ children }: { children: ReactNode }) => {
  const [shops, setShops] = useState<Shop[]>(INITIAL_SHOPS);
  const [materials, setMaterials] = useState<Material[]>(INITIAL_MATERIALS);
  const [cart, setCart] = useState<{ materialId: number; quantity: number }[]>([]);

  const addShop = (shop: Omit<Shop, "id">) => {
    const newShop = { ...shop, id: Date.now() };
    setShops([...shops, newShop]);
  };

  const addMaterial = (material: Omit<Material, "id">) => {
    const newMaterial = { ...material, id: Date.now() };
    setMaterials([...materials, newMaterial]);
  };

  const getMaterialsByShop = (shopId: number) => {
    return materials.filter((m) => m.shopId === shopId);
  };

  const addToCart = (materialId: number, quantity: number) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.materialId === materialId);
      if (existing) {
        return prev.map((item) =>
          item.materialId === materialId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { materialId, quantity }];
    });
  };

  const updateCartQuantity = (materialId: number, quantity: number) => {
    if (quantity <= 0) {
        removeFromCart(materialId);
        return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.materialId === materialId ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (materialId: number) => {
    setCart((prev) => prev.filter((item) => item.materialId !== materialId));
  };

  const clearCart = () => setCart([]);

  return (
    <DataContext.Provider
      value={{
        shops,
        materials,
        addShop,
        addMaterial,
        getMaterialsByShop,
        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
};
