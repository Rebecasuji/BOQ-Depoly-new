import { Link } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Printer, Share2 } from "lucide-react";
import { useData } from "@/lib/store";

export default function CostSummary() {
  const { cart, materials } = useData();

  const cartItems = cart.map(item => {
    const mat = materials.find(m => m.id === item.materialId);
    return {
        ...item,
        ...mat,
        total: (mat?.rate || 0) * item.quantity
    };
  }).filter(item => item.name); // Filter out if material deleted

  const totalCost = cartItems.reduce((acc, curr) => acc + curr.total, 0);

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4 no-print">
            <Link href="/item-master">
                <Button variant="ghost" size="icon">
                    <ArrowLeft className="h-5 w-5" />
                </Button>
            </Link>
            <div>
                <h2 className="text-3xl font-bold tracking-tight font-display text-primary">Cost Summary</h2>
                <p className="text-muted-foreground">Final Bill of Quantities and Cost Estimation</p>
            </div>
            <div className="ml-auto flex gap-2">
                <Button variant="outline" onClick={() => window.print()}>
                    <Printer className="mr-2 h-4 w-4" /> Print
                </Button>
                <Button variant="outline">
                    <Share2 className="mr-2 h-4 w-4" /> Share
                </Button>
            </div>
        </div>

        <Card className="border-2 border-border">
            <CardHeader className="bg-muted/30 border-b">
                <div className="flex justify-between items-center">
                    <CardTitle>Project Estimate</CardTitle>
                    <span className="text-sm text-muted-foreground">Date: {new Date().toLocaleDateString()}</span>
                </div>
            </CardHeader>
            <CardContent className="p-0">
                <div className="grid grid-cols-12 bg-muted/50 p-4 text-sm font-semibold border-b">
                    <div className="col-span-5">Item Description</div>
                    <div className="col-span-2 text-right">Rate</div>
                    <div className="col-span-2 text-right">Qty</div>
                    <div className="col-span-3 text-right">Amount</div>
                </div>
                
                {cartItems.length === 0 ? (
                    <div className="p-8 text-center text-muted-foreground">
                        No materials selected. Please go back to Item Master to add materials.
                    </div>
                ) : (
                    cartItems.map((item, idx) => (
                        <div key={idx} className="grid grid-cols-12 p-4 border-b text-sm items-center hover:bg-muted/10">
                            <div className="col-span-5">
                                <div className="font-medium">{item.name}</div>
                                <div className="text-xs text-muted-foreground">Code: {item.code}</div>
                            </div>
                            <div className="col-span-2 text-right">₹{item.rate}</div>
                            <div className="col-span-2 text-right">{item.quantity} {item.unit}</div>
                            <div className="col-span-3 text-right font-mono font-medium">₹{item.total.toLocaleString()}</div>
                        </div>
                    ))
                )}

                <div className="grid grid-cols-12 p-6 bg-primary/5">
                    <div className="col-span-9 text-right font-bold text-lg pr-4">Grand Total</div>
                    <div className="col-span-3 text-right font-bold text-xl text-primary">₹{totalCost.toLocaleString()}</div>
                </div>
            </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
