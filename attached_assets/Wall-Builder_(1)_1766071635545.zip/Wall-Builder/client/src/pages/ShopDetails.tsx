import { useState } from "react";
import { useParams, Link } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, ShoppingCart, ArrowLeft, Plus, Minus, ArrowRight } from "lucide-react";
import { useData } from "@/lib/store";

export default function ShopDetails() {
  const { id } = useParams();
  const { shops, getMaterialsByShop, cart, addToCart, updateCartQuantity } = useData();
  const [searchTerm, setSearchTerm] = useState("");

  const shopId = Number(id);
  const shop = shops.find(s => s.id === shopId);
  const materials = getMaterialsByShop(shopId);

  const filteredMaterials = materials.filter(m => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    m.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getCartQuantity = (materialId: number) => {
    return cart.find(i => i.materialId === materialId)?.quantity || 0;
  };

  if (!shop) return <div className="p-8">Shop not found</div>;

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
            <Link href="/item-master">
                <Button variant="ghost" size="icon">
                    <ArrowLeft className="h-5 w-5" />
                </Button>
            </Link>
            <div>
                <h2 className="text-3xl font-bold tracking-tight font-display text-primary">{shop.name}</h2>
                <p className="text-muted-foreground">Browse and select materials for your estimate.</p>
            </div>
            <div className="ml-auto">
                <Link href="/cost-summary">
                    <Button className="bg-primary text-primary-foreground">
                        <ShoppingCart className="mr-2 h-4 w-4" /> 
                        View Summary ({cart.length})
                        <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                </Link>
            </div>
        </div>

        <div className="flex gap-4">
            <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input 
                    placeholder="Search materials..." 
                    className="pl-9"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
        </div>

        <div className="space-y-2">
            {filteredMaterials.map((item) => {
                const qty = getCartQuantity(item.id);
                return (
                    <Card key={item.id} className="overflow-hidden hover:bg-muted/30 transition-colors">
                        <CardContent className="p-3 flex items-center gap-4">
                            <img 
                                src={item.image || "https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&q=80&w=100&h=100"} 
                                alt={item.name} 
                                className="w-12 h-12 rounded object-cover bg-muted" 
                            />
                            
                            <div className="flex-1">
                                <h4 className="font-semibold">{item.name}</h4>
                                <div className="flex gap-2 text-xs text-muted-foreground">
                                    <span>Code: {item.code}</span>
                                    <span>•</span>
                                    <span>{item.category}</span>
                                </div>
                            </div>

                            <div className="text-right mr-4 w-24">
                                <div className="font-bold text-lg">₹{item.rate}</div>
                                <div className="text-xs text-muted-foreground">per {item.unit}</div>
                            </div>

                            {qty === 0 ? (
                                <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => addToCart(item.id, 1)}
                                    className="w-32"
                                >
                                    <Plus className="mr-2 h-4 w-4" /> Add
                                </Button>
                            ) : (
                                <div className="flex items-center gap-2 w-32 justify-center bg-muted rounded-md p-1">
                                    <Button 
                                        size="icon" 
                                        variant="ghost" 
                                        className="h-6 w-6"
                                        onClick={() => updateCartQuantity(item.id, qty - 1)}
                                    >
                                        <Minus className="h-3 w-3" />
                                    </Button>
                                    <span className="font-mono text-sm w-8 text-center">{qty}</span>
                                    <Button 
                                        size="icon" 
                                        variant="ghost" 
                                        className="h-6 w-6"
                                        onClick={() => updateCartQuantity(item.id, qty + 1)}
                                    >
                                        <Plus className="h-3 w-3" />
                                    </Button>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                );
            })}
        </div>
      </div>
    </Layout>
  );
}
