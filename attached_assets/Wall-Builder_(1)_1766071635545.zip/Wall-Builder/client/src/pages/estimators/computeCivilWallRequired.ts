export interface CivilWallComputeResult {
  area: number;
  wallVolume: number;
  bricks: number;
  cementBags: number;
  sandCft: number;
  gypsumSheets: number;
  plywoodSheets: number;
  glassArea: number;
  framingLength: number; // GI or Wood
  screws: number;
  jointCompound: number;
}

export const computeCivilWallRequired = (
  wallType: string | null,
  length: number | null,
  height: number | null,
  subOption: string | null,
  plywoodSelection: any = {}
): CivilWallComputeResult | null => {
  if (!wallType || !length || !height) return null;

  const area = length * height;
  let result: CivilWallComputeResult = {
    area,
    wallVolume: 0,
    bricks: 0,
    cementBags: 0,
    sandCft: 0,
    gypsumSheets: 0,
    plywoodSheets: 0,
    glassArea: 0,
    framingLength: 0,
    screws: 0,
    jointCompound: 0
  };

  if (wallType === "civil") {
    // Standard Brick Wall Calculation
    // Thickness: 9 inch (0.75 ft) or 4.5 inch (0.375 ft)
    const thickness = subOption === "9 inch" ? 0.75 : 0.375;
    const volume = area * thickness; // Cubic feet
    result.wallVolume = volume;

    // Standard brick size with mortar: 9"x4.5"x3" approx
    // Bricks per cubic foot approx 13.5
    // For 4.5" wall, usually calc by sqft: ~4.5 to 5 bricks per sqft
    // For 9" wall, ~9-10 bricks per sqft
    
    if (subOption === "9 inch") {
        result.bricks = Math.ceil(area * 10);
        // Mortar ratio 1:6
        // Approx 1.5 bags cement per 100 sqft for 9" wall
        result.cementBags = Math.ceil((area / 100) * 1.5);
        // Sand: ~18 cft per 100 sqft
        result.sandCft = Math.ceil((area / 100) * 18);
    } else {
        result.bricks = Math.ceil(area * 5);
        // Mortar ratio 1:4
        // Approx 0.8 bags cement per 100 sqft
        result.cementBags = Math.ceil((area / 100) * 0.8);
        // Sand: ~10 cft per 100 sqft
        result.sandCft = Math.ceil((area / 100) * 10);
    }
  } 
  else if (wallType === "gypsum") {
    // Gypsum Partition
    // Double sided standard: 2 sheets per area (front/back)
    const sides = subOption === "Double Glazing" ? 2 : 2; // Usually partitions are both sides
    // Sheet size 6x4 = 24 sqft
    result.gypsumSheets = Math.ceil((area * sides) / 24);
    
    // Framing: GI Channels
    // Floor + Ceiling track = Length * 2
    // Vertical studs every 2ft = (Length/2 + 1) * Height
    const tracks = length * 2;
    const studs = (Math.ceil(length / 2) + 1) * height;
    result.framingLength = Math.ceil(tracks + studs);
    
    // Screws: ~15 per sheet
    result.screws = result.gypsumSheets * 15;
    
    // Joint compound: ~0.5kg per sheet
    result.jointCompound = Math.ceil(result.gypsumSheets * 0.5);
  }
  else if (wallType === "plywood") {
    // Plywood Partition
    // 8x4 sheets = 32 sqft
    result.plywoodSheets = Math.ceil((area * 2) / 32); // Double sided
    
    // Wooden or Aluminium Framing (similar logic to gypsum but different framing material)
    const tracks = length * 2;
    const studs = (Math.ceil(length / 2) + 1) * height;
    result.framingLength = Math.ceil(tracks + studs);
    
    result.screws = result.plywoodSheets * 20;
  }
  else if (wallType === "gypsum-glass" || wallType === "plywood-glass") {
    // Mixed
    // Assume 50-50 split or custom if we had that input, for now assuming 50% glass
    const solidArea = area * 0.5;
    const glassPart = area * 0.5;
    
    result.glassArea = glassPart;
    
    if (wallType.includes("gypsum")) {
        result.gypsumSheets = Math.ceil((solidArea * 2) / 24);
    } else {
        result.plywoodSheets = Math.ceil((solidArea * 2) / 32);
    }
    
    // Framing for whole wall
    result.framingLength = Math.ceil((length * 2) + ((Math.ceil(length / 2) + 1) * height));
  }

  return result;
};
