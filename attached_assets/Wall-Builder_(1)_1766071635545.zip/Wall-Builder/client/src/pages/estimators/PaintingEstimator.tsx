import { useState } from "react";
import { Link } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, ChevronRight, ChevronLeft, Calculator } from "lucide-react";

const paintTypes = [
  { label: "Interior Wall Painting", value: "interior" },
  { label: "Exterior Wall Painting", value: "exterior" },
  { label: "Wood / Metal Enamel", value: "enamel" },
];

const subOptions = {
    interior: ["Premium Emulsion", "Standard Emulsion", "Distemper", "Royal Play Texture"],
    exterior: ["Weather Coat Smooth", "Weather Coat Texture", "Cement Paint"],
    enamel: ["Gloss Finish", "Satin Finish", "Matte Finish"]
};

export default function PaintingEstimator() {
  const [step, setStep] = useState(1);
  const [type, setType] = useState<string | null>(null);
  const [subType, setSubType] = useState<string | null>(null);
  const [dimensions, setDimensions] = useState({ area: "" });
  const [materials, setMaterials] = useState<any[]>([]);

  const handleNext = () => setStep(prev => prev + 1);
  const handleBack = () => setStep(prev => prev - 1);

  const calculate = () => {
    const area = parseFloat(dimensions.area) || 0;
    let mats = [];
    
    // Coverage rates (approx)
    const primerCoverage = 120; // sqft/liter
    const puttyCoverage = 15; // sqft/kg
    const paintCoverage = type === 'interior' ? 80 : 60; // sqft/liter (2 coats)

    // Base materials for all wall painting
    if (type !== 'enamel') {
        mats.push({ item: "Wall Putty", description: "2 Coats", quantity: area / puttyCoverage, unit: "kg" });
        mats.push({ item: "Wall Primer", description: "1 Coat", quantity: area / primerCoverage, unit: "liters" });
        mats.push({ item: `${subType} Paint`, description: "2 Coats Finish", quantity: area / paintCoverage, unit: "liters" });
        mats.push({ item: "Painting Tools", description: "Roller, Brush, Sandpaper", quantity: 1, unit: "set" });
    } else {
        mats.push({ item: "Wood Primer / Metal Primer", description: "Base coat", quantity: area / 100, unit: "liters" });
        mats.push({ item: `${subType} Enamel`, description: "2 Coats Finish", quantity: area / 90, unit: "liters" });
        mats.push({ item: "Thinner / Turpentine", description: "Solvent", quantity: (area / 90) * 0.15, unit: "liters" });
    }

    setMaterials(mats);
    handleNext();
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight font-display text-primary">Painting Estimator</h2>
          <p className="text-muted-foreground">Calculate paint quantities and required materials.</p>
        </div>

        <div className="flex items-center justify-between mb-8 relative">
           <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-full h-1 bg-muted z-0"></div>
           {[1, 2, 3, 4].map((s) => (
            <div key={s} className={cn("relative z-10 w-10 h-10 rounded-full flex items-center justify-center font-bold border-2 transition-colors duration-300", step >= s ? "bg-primary border-primary text-primary-foreground" : "bg-background border-muted text-muted-foreground")}>
              {step > s ? <CheckCircle2 className="h-6 w-6" /> : s}
            </div>
           ))}
        </div>

        <Card className="border-border/50 shadow-lg">
          <CardContent className="p-6">
            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                  <h3 className="text-xl font-semibold">Step 1: Select Painting Type</h3>
                  <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
                    {paintTypes.map((opt) => (
                      <Button key={opt.value} variant={type === opt.value ? "default" : "outline"} className={cn("h-20 text-lg justify-start px-6", type === opt.value ? "border-primary bg-primary/10 text-primary" : "")} onClick={() => setType(opt.value)}>
                        {opt.label}
                      </Button>
                    ))}
                  </div>
                   <div className="flex justify-end pt-4"><Button onClick={handleNext} disabled={!type} className="w-32">Next <ChevronRight className="ml-2 h-4 w-4" /></Button></div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                  <h3 className="text-xl font-semibold">Step 2: Select Finish</h3>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {type && subOptions[type as keyof typeof subOptions]?.map((opt) => (
                      <Button key={opt} variant={subType === opt ? "default" : "outline"} className={cn("h-16 text-lg justify-start px-6", subType === opt ? "border-primary bg-primary/10 text-primary" : "")} onClick={() => setSubType(opt)}>
                        {opt}
                      </Button>
                    ))}
                  </div>
                  <div className="flex justify-between pt-6">
                    <Button variant="outline" onClick={handleBack} className="w-32"><ChevronLeft className="mr-2 h-4 w-4" /> Back</Button>
                    <Button onClick={handleNext} disabled={!subType} className="w-32">Next <ChevronRight className="ml-2 h-4 w-4" /></Button>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                  <h3 className="text-xl font-semibold">Step 3: Total Paintable Area</h3>
                  <div className="grid grid-cols-1 gap-6">
                    <div className="space-y-2">
                        <Label>Total Area (sq.ft)</Label>
                        <Input type="number" placeholder="Enter total wall area" value={dimensions.area} onChange={(e) => setDimensions({area: e.target.value})} />
                        <p className="text-xs text-muted-foreground">Tip: Wall Height × Wall Length (minus doors/windows)</p>
                    </div>
                  </div>
                  <div className="flex justify-between pt-6">
                    <Button variant="outline" onClick={handleBack} className="w-32"><ChevronLeft className="mr-2 h-4 w-4" /> Back</Button>
                    <Button onClick={calculate} className="w-40 bg-green-600 hover:bg-green-700 text-white"><Calculator className="mr-2 h-4 w-4" /> Calculate</Button>
                  </div>
                </motion.div>
              )}

              {step === 4 && (
                <motion.div key="s4" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="space-y-6">
                   <div className="text-center space-y-2">
                    <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto text-blue-500"><Calculator className="h-8 w-8" /></div>
                    <h3 className="text-2xl font-bold">Material Requirements</h3>
                    <p className="text-muted-foreground">Required paint and consumables</p>
                  </div>
                  <div className="bg-muted/30 rounded-lg border border-border overflow-hidden">
                    <div className="grid grid-cols-12 bg-muted p-3 text-sm font-medium">
                        <div className="col-span-8">Item Description</div>
                        <div className="col-span-4 text-right">Qty</div>
                    </div>
                    {materials.map((mat, idx) => (
                         <div key={idx} className="grid grid-cols-12 p-4 border-b border-border/50 text-sm items-center">
                            <div className="col-span-8">
                                <div className="font-medium text-foreground">{mat.item}</div>
                                <div className="text-xs text-muted-foreground">{mat.description}</div>
                            </div>
                            <div className="col-span-4 text-right font-mono text-lg">{mat.quantity.toFixed(1)} <span className="text-xs text-muted-foreground">{mat.unit}</span></div>
                        </div>
                    ))}
                  </div>
                   <div className="flex justify-between pt-6">
                    <Button variant="outline" onClick={() => setStep(1)} className="w-32">Start Over</Button>
                    <Link href="/item-master"><Button className="w-48 bg-primary text-primary-foreground">Select Materials <ChevronRight className="ml-2 h-4 w-4" /></Button></Link>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
