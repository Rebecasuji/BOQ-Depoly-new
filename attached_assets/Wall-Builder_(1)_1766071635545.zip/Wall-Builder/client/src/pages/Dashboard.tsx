import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  BrickWall, 
  DoorOpen, 
  Layers, 
  Zap, 
  Activity,
  Calendar,
  DollarSign
} from "lucide-react";
import { motion } from "framer-motion";

const stats = [
  { label: "Active Projects", value: "12", icon: Activity, color: "text-blue-500" },
  { label: "Pending Estimates", value: "5", icon: Calendar, color: "text-orange-500" },
  { label: "Total Estimated Value", value: "$1.2M", icon: DollarSign, color: "text-green-500" },
];

const recentEstimates = [
  { id: "EST-001", client: "Acme Corp", type: "Civil Wall", date: "2023-10-15", status: "Completed" },
  { id: "EST-002", client: "John Smith", type: "Flooring", date: "2023-10-14", status: "Pending" },
  { id: "EST-003", client: "Tech Solutions", type: "Electrical", date: "2023-10-12", status: "In Progress" },
];

export default function Dashboard() {
  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h2 className="text-3xl font-bold tracking-tight font-display">Dashboard</h2>
          <p className="text-muted-foreground">Overview of your construction estimates and projects.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-3">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {stat.label}
                  </CardTitle>
                  <stat.icon className={`h-4 w-4 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Quick Actions & Recent */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
          <Card className="col-span-4">
            <CardHeader>
              <CardTitle>Recent Estimates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentEstimates.map((est) => (
                  <div key={est.id} className="flex items-center justify-between border-b border-border/50 pb-2 last:border-0 last:pb-0">
                    <div className="space-y-1">
                      <p className="text-sm font-medium leading-none">{est.client}</p>
                      <p className="text-xs text-muted-foreground">{est.type} • {est.id}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-xs text-muted-foreground">{est.date}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        est.status === "Completed" ? "bg-green-500/10 text-green-500" :
                        est.status === "Pending" ? "bg-orange-500/10 text-orange-500" :
                        "bg-blue-500/10 text-blue-500"
                      }`}>
                        {est.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="col-span-3">
            <CardHeader>
              <CardTitle>Quick Estimator</CardTitle>
              <CardDescription>Start a new estimate</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-2">
              <div className="grid grid-cols-2 gap-2">
                <div className="p-4 bg-primary/10 rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-primary/20 cursor-pointer transition-colors border border-primary/20">
                  <BrickWall className="h-6 w-6 text-primary" />
                  <span className="text-xs font-medium">Civil Wall</span>
                </div>
                <div className="p-4 bg-muted rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-muted/80 cursor-pointer transition-colors">
                  <DoorOpen className="h-6 w-6 text-foreground" />
                  <span className="text-xs font-medium">Doors</span>
                </div>
                <div className="p-4 bg-muted rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-muted/80 cursor-pointer transition-colors">
                  <Layers className="h-6 w-6 text-foreground" />
                  <span className="text-xs font-medium">Flooring</span>
                </div>
                <div className="p-4 bg-muted rounded-lg flex flex-col items-center justify-center gap-2 hover:bg-muted/80 cursor-pointer transition-colors">
                  <Zap className="h-6 w-6 text-foreground" />
                  <span className="text-xs font-medium">Electrical</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
