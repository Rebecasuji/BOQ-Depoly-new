import { useState } from "react";
import { Link } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Building2 } from "lucide-react";
import { useData } from "@/lib/store";

export default function AdminDashboard() {
  const { toast } = useToast();
  const { shops, materials, addShop, addMaterial } = useData();

  const [newShop, setNewShop] = useState({ name: "", location: "", phone: "" });
  const [newMaterial, setNewMaterial] = useState({ name: "", code: "", rate: "", shopId: "", unit: "pcs", category: "General" });

  const handleAddShop = () => {
    if (!newShop.name) return;
    addShop(newShop);
    setNewShop({ name: "", location: "", phone: "" });
    toast({ title: "Success", description: "Shop added successfully" });
  };

  const handleAddMaterial = () => {
    if (!newMaterial.name || !newMaterial.rate || !newMaterial.shopId) return;
    addMaterial({
        name: newMaterial.name,
        code: newMaterial.code,
        rate: Number(newMaterial.rate),
        shopId: Number(newMaterial.shopId),
        unit: newMaterial.unit,
        category: newMaterial.category
    });
    setNewMaterial({ name: "", code: "", rate: "", shopId: "", unit: "pcs", category: "General" });
    toast({ title: "Success", description: "Material added successfully" });
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight font-display text-primary">Admin Dashboard</h2>
          <p className="text-muted-foreground">Manage organizations, shops, and item master.</p>
        </div>

        <Tabs defaultValue="shops" className="w-full">
          <TabsList className="w-full max-w-md grid grid-cols-2">
            <TabsTrigger value="shops">Manage Shops</TabsTrigger>
            <TabsTrigger value="materials">Item Master</TabsTrigger>
          </TabsList>

          <TabsContent value="shops" className="space-y-4 mt-4">
            <Card>
              <CardContent className="space-y-4 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                        <Label>Shop Name</Label>
                        <Input value={newShop.name} onChange={e => setNewShop({...newShop, name: e.target.value})} placeholder="e.g. City Hardware" />
                    </div>
                    <div className="space-y-2">
                        <Label>Location</Label>
                        <Input value={newShop.location} onChange={e => setNewShop({...newShop, location: e.target.value})} placeholder="e.g. Downtown" />
                    </div>
                    <div className="space-y-2">
                        <Label>Phone</Label>
                        <Input value={newShop.phone} onChange={e => setNewShop({...newShop, phone: e.target.value})} placeholder="Contact Number" />
                    </div>
                </div>
                <Button onClick={handleAddShop} className="w-full md:w-auto"><Plus className="mr-2 h-4 w-4" /> Add Shop</Button>
              </CardContent>
            </Card>

            <div className="grid gap-4 md:grid-cols-2">
                {shops.map(shop => (
                    <Card key={shop.id}>
                        <CardContent className="flex flex-row items-center justify-between p-6">
                            <div>
                                <h3 className="text-lg font-bold flex items-center gap-2">
                                    <Building2 className="h-4 w-4" /> {shop.name}
                                </h3>
                                <div className="text-sm text-muted-foreground">{shop.location} • {shop.phone}</div>
                            </div>
                            <Button variant="ghost" size="icon" className="text-destructive"><Trash2 className="h-4 w-4" /></Button>
                        </CardContent>
                    </Card>
                ))}
            </div>
          </TabsContent>

          <TabsContent value="materials" className="space-y-4 mt-4">
            <Card>
              <CardContent className="space-y-4 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="space-y-2">
                        <Label>Material Name</Label>
                        <Input value={newMaterial.name} onChange={e => setNewMaterial({...newMaterial, name: e.target.value})} placeholder="Item Name" />
                    </div>
                    <div className="space-y-2">
                        <Label>Item Code</Label>
                        <Input value={newMaterial.code} onChange={e => setNewMaterial({...newMaterial, code: e.target.value})} placeholder="SKU / Code" />
                    </div>
                    <div className="space-y-2">
                        <Label>Rate (₹)</Label>
                        <Input type="number" value={newMaterial.rate} onChange={e => setNewMaterial({...newMaterial, rate: e.target.value})} placeholder="0.00" />
                    </div>
                    <div className="space-y-2">
                        <Label>Unit</Label>
                        <Input value={newMaterial.unit} onChange={e => setNewMaterial({...newMaterial, unit: e.target.value})} placeholder="pcs, kg, mtr" />
                    </div>
                    <div className="space-y-2">
                        <Label>Category</Label>
                        <Input value={newMaterial.category} onChange={e => setNewMaterial({...newMaterial, category: e.target.value})} placeholder="Civil, Electric" />
                    </div>
                    <div className="space-y-2">
                        <Label>Supplier</Label>
                        <select 
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                            value={newMaterial.shopId}
                            onChange={e => setNewMaterial({...newMaterial, shopId: e.target.value})}
                        >
                            <option value="">Select Shop</option>
                            {shops.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                    </div>
                </div>
                <Button onClick={handleAddMaterial} className="w-full md:w-auto"><Plus className="mr-2 h-4 w-4" /> Add Material</Button>
              </CardContent>
            </Card>

            <Card>
                <CardContent className="p-0">
                    <div className="rounded-md">
                        <div className="grid grid-cols-12 bg-muted p-3 text-sm font-medium">
                            <div className="col-span-4">Item Name</div>
                            <div className="col-span-2">Code</div>
                            <div className="col-span-2">Category</div>
                            <div className="col-span-2">Rate</div>
                            <div className="col-span-2 text-right">Action</div>
                        </div>
                        {materials.map(mat => (
                            <div key={mat.id} className="grid grid-cols-12 p-3 border-t text-sm items-center hover:bg-muted/10">
                                <div className="col-span-4 font-medium">{mat.name}</div>
                                <div className="col-span-2 text-muted-foreground">{mat.code}</div>
                                <div className="col-span-2 text-xs bg-secondary/50 rounded px-2 py-1 w-fit">{mat.category}</div>
                                <div className="col-span-2">₹{mat.rate} / {mat.unit}</div>
                                <div className="col-span-2 text-right">
                                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="h-4 w-4" /></Button>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
